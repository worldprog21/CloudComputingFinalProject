/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;
import javax.swing.JOptionPane;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.core.CloudSim;

/**
 *
 * @author CabinK1
 */
public class file2 {
     public static org.cloudbus.cloudsim.Datacenter dataCenter[];
    public static int nofDatacenter,nofBrokers;
    String str;
    public static String dcName,bName;
    public static ArrayList details =new ArrayList();
    public static DatacenterBroker[] bId;
    
     private static DatacenterBroker createBroker(){
                
	    	DatacenterBroker broker = null;
	        try {
			broker = new DatacenterBroker(bName);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	    	return broker;
	    }
   
    void broker(){
        Connection con=null;
        Statement st=null;
        ResultSet rs=null;
        try{
               Class.forName("com.mysql.jdbc.Driver");
            con=(Connection)(java.sql.Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/ACO","root","");
           st = con.createStatement();
           st.executeUpdate("TRUNCATE TABLE broker");
            BufferedWriter bw=new BufferedWriter(new FileWriter("broker.txt"));
            System.out.println("Enter the number of Broker: \n");
        Scanner sc=new Scanner(System.in);
//        str=jTextField1.getText();
           nofBrokers=sc.nextInt();
        DatacenterBroker broker;
        bId=new DatacenterBroker[nofBrokers];
        int brokerId;
        String brokerName;
        System.out.print("DatacenterBroker"+"\tBroker Id\n\n");
        bw.write("DatacenterBroker"+"\tBroker Id");
        bw.newLine();
        System.out.print("===============================================\n\n");
        for(int i=0;i<nofBrokers;i++)
        {
            bName="Broker_"+i;            
            broker=createBroker();
            bId[i]=broker;
            brokerId=broker.getId();
            brokerName=broker.getName();
            System.out.print(brokerName+"\t\t"+brokerId+" "+"\n\n");
            System.out.print("id : "+brokerId+" name : "+brokerName);
         st.executeUpdate("INSERT INTO broker VALUES('"+brokerId+"','"+brokerName+"')");
            bw.write(brokerName+"\t"+brokerId);
            bw.newLine();
        }
        bw.close();
       // JOptionPane.showMessageDialog(null,nofBrokers+ " created successfully");
        }catch(Exception e){e.printStackTrace();}
        
    }
    
   
    
    
    
//    void brokerclass(String ss){
//        CloudSim.init(1, Calendar.getInstance(), false);
//        System.out.println("started");
//      file2 f2=new file2();
//      f2.broker(ss);
//    }
    
}
