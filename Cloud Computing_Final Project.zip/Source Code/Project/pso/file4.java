/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;

/**
 *
 * @author CabinK1
 */
public class file4 {
    
    public static String str;
    public int nofVm,nofCloudlets;
    public static List<Vm> vmlist;
    public static List<org.cloudbus.cloudsim.Cloudlet> cloudletList;
    public static DatacenterBroker[] broker=file2.bId;
    public static ArrayList vDetails=new ArrayList();
    public int pesNumber=1;

    void cloudletclass()
    {
        System.out.println("Cloudlet");
  Connection con=null;
  Statement st=null;
  ResultSet rs=null;
       try{
           Class.forName("com.mysql.jdbc.Driver");
            con=(Connection)(java.sql.Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/ACO","root","");
           st = con.createStatement();
           st.executeQuery("TRUNCATE TABLE cloudlet");
             BufferedWriter bw1=new BufferedWriter(new FileWriter("cloudlet.txt"));
        System.out.println("Enter Number of Cloudlets :"); 
        int cl;
        Scanner sc=new Scanner(System.in);
        cl=sc.nextInt();
       
        nofCloudlets=cl;
      
        
     //   int nofUsers=Integer.parseInt(str1);
        cloudletList = new ArrayList<org.cloudbus.cloudsim.Cloudlet>();
        Random r=new Random();
        Random r1=new Random();
        Random r2=new Random();
        Random r3=new Random();
        int b;//=r.nextInt(broker.length);
        int brokerId;
        int l,f,o;
        
        ArrayList cList=new ArrayList();
        ArrayList cDetails=new ArrayList();
        DatacenterBroker sBroker;
        int id;
        long length;
        long fileSize;
        long outputSize;
        for(int i=0;i<nofCloudlets;i++)
        {
            do{
                l=r1.nextInt(60000);
            }while(l<30000);
            do{
                f=r2.nextInt(6000);
            }while(l<300);
            do{
                pesNumber=r3.nextInt(4);
            }while(pesNumber<1);
            length=(long)l;
            fileSize=(long)f;
            outputSize=(long)f;
            b=r.nextInt(broker.length);
            id=i;
            brokerId=broker[b].getId();
            UtilizationModel utilizationModel = new UtilizationModelFull();
            org.cloudbus.cloudsim.Cloudlet cloudlet1 = new org.cloudbus.cloudsim.Cloudlet(id, length, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
            cloudlet1.setUserId(brokerId);
            cDetails.add(id+"\t"+brokerId+"\t"+length+"\t"+fileSize+"\t"+outputSize);
            st.executeUpdate("INSERT INTO cloudlet VALUES('"+id+"','"+brokerId+"','"+length+"','"+fileSize+"','"+outputSize+"')");
            
          //  System.out.println("id : "+id);
            sBroker=broker[b];
            cList.add(cloudlet1);
            cloudletList.add(cloudlet1);
            sBroker.submitCloudletList(cList);            
            cList.clear();
        }       
     System.out.println();
       System.out.println("Cloudlet Id"+"\t"+"Broker Id"+"\t"+"Length"+" \t"+"fileSize"+"\t"+"outputSize"+"\n");
       bw1.write("CloudletId"+"\t"+"BrokerId"+"\t"+"Length"+" \t"+"fileSize"+"\t"+"outputSize");
       bw1.newLine();
        System.out.println("====================================================================\n\n");
        for(int i=0;i<cDetails.size();i++)
        {
            System.out.println(cDetails.get(i).toString()+"\n");
            bw1.write(cDetails.get(i).toString());
            bw1.newLine();
        }
     bw1.close();
        for(int i=0;i<broker.length;i++)
        {
            System.out.println(i+" 1: "+broker[i].getCloudletList().size());
        }
        
       }catch(Exception e){e.printStackTrace();}
    }
    
   
     
  
}
