/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.StringTokenizer;

/**
 *
 * @author ETPL10
 */
public class file5 {
     public static ArrayList<Long>ar=new ArrayList<Long>();
    public static ArrayList<String>ar1=new ArrayList<String>();
      public static ArrayList<String>ar3=new ArrayList<String>();
      public static ArrayList<Long>cldfs=new ArrayList<Long>();
      public static ArrayList<String>cid=new ArrayList<String>();
       public static ArrayList<Long>vmbw=new ArrayList<Long>();
      public static ArrayList<String>vmid=new ArrayList<String>();
      public static ArrayList<String>vmid1=new ArrayList<String>();
      public void cloudlet(){
         Connection con=null;
        Statement st=null,st1=null;
        ResultSet rs=null,rs1=null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=(Connection)(java.sql.Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/ACO","root","");
           st = con.createStatement();
             st1 = con.createStatement();
           st.executeUpdate("TRUNCATE TABLE dist");
           System.out.println("Fitness Value of Cloudlet\n************************************************************\n");
           rs=st.executeQuery("SELECT * FROM cloudlet");
            rs1=st1.executeQuery("SELECT * FROM vm");
            while(rs1.next()){
                String a=rs1.getString(1);
                vmid.add(a);
                vmid1.add(a);
                long b=rs1.getLong(5);
                vmbw.add(b);
            }
           while(rs.next()){
               long a=rs.getLong(4);
               String b=rs.getString(1);
//               cid.add(b);
               ar1.add(b);
               System.out.println(a);
               ar.add(a);
//               cldfs.add(a);
               
           }
           System.out.println("Cloudlet1\tCloudlet2\tDistance\n************************************************************\n");
           for(int i=0;i<ar.size();i++){
               for(int j=0;j<ar.size();j++){
                   double dist=Math.sqrt((ar.get(i)-ar.get(j))*(ar.get(i)-ar.get(j)));
                   if(dist!=0){
                   st.executeUpdate("INSERT INTO dist VALUES('"+ar1.get(i)+"','"+ar1.get(j)+"','"+dist+"')");
                   }
                   System.out.println(ar1.get(i)+"\t\t"+ar1.get(j)+"\t\t"+dist);
               }
           }
           
        }catch(Exception e){e.printStackTrace();}
    }
      
      
       public static ArrayList<String>cl=new ArrayList<String>();
    void opt(){
        Connection con=null;
        Statement st=null,st1=null,st2=null,st3=null,st4=null,st5=null,st6=null,st7=null;
        ResultSet rs=null,rs1=null,rs2=null,rs3=null,rs4=null,rs5=null;
        try{
             Class.forName("com.mysql.jdbc.Driver");
            con=(Connection)(java.sql.Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/ACO","root","");
           st = con.createStatement();
           st1=con.createStatement();
           st2=con.createStatement();
           st3=con.createStatement();
            st4=con.createStatement();
              st5=con.createStatement();
              st6=con.createStatement();
                st7=con.createStatement();
              st6.executeUpdate("TRUNCATE TABLE opt1");
           st3.executeUpdate("TRUNCATE TABLE opt");
           rs1=st.executeQuery("SELECT distinct(cloudlet1) FROM dist");
           while(rs1.next()){
               String a=rs1.getString(1);
             
               cl.add(a);
           }
           ArrayList<Double>ar3=new ArrayList<Double>();
       for(int i=0;i<cl.size();i++){
            rs=st.executeQuery("SELECT min(euclideandistance) from dist where cloudlet1='"+cl.get(i)+"'");
            while(rs.next()){
                double a=rs.getDouble(1);
            ar3.add(a);
            // System.out.println(a+"\t"+cl.get(i));
            }
       }
       ArrayList<String>pp=new ArrayList<String>();
     System.out.println("Minimum Distance Cloudlets\n****************************************\n");
       for(int j=0;j<cl.size();j++){
           rs2=st2.executeQuery("SELECT * FROM dist WHERE cloudlet1='"+cl.get(j)+"' and euclideandistance='"+ar3.get(j)+"'");
           while(rs2.next()){
               String a=rs2.getString(1);
               String b=rs2.getString(2);
               String c=rs2.getString(3);
               if(!pp.contains(a)&&!pp.contains(b)){
                   pp.add(a);pp.add(b);
               System.out.println(a+"\t"+b+"\t"+c);
               st3.executeUpdate("INSERT INTO opt VALUES('"+a+"','"+b+"','"+c+"')");
               }
           }
       }
       
       rs3=st3.executeQuery("SELECT * FROM opt ORDER BY dist ASC");
       ArrayList<String>ar4=new ArrayList<String>();
       while(rs3.next()){
           String a=rs3.getString(1);
           String b=rs3.getString(2);
           String c=rs3.getString(3);
           ar4.add(a+","+b);
       }
       System.out.println("Optimized Cloudlets\n***************************\n");
       ArrayList<String>dd1=new ArrayList<String>();
       for(int i=0;i<ar4.size();i++){
         StringTokenizer stt=new StringTokenizer(ar4.get(i),",");
         String tk="";
           double d=0;
         while(stt.hasMoreTokens()){
             String a=stt.nextToken();
            
             rs4=st5.executeQuery("SELECT * FROM cloudlet");
          
             while(rs4.next()){
               String aa=rs4.getString(1);
               double bb=rs4.getDouble(4);
               if(aa.equals(a)){
                   d=d+bb;
               }
//                 System.out.println("d1"+d1);
             }
             if(!dd1.contains(ar4.get(i))){
            dd1.add(ar4.get(i));
             tk=ar4.get(i)+"\t"+d;
             cid.add(ar4.get(i));
             cldfs.add((long)d);
             st6.executeUpdate("INSERT INTO opt1 VALUES('"+ar4.get(i)+"','"+d+"')");
             }
             }
           System.out.println(tk);
         
       }
//       for(int i=0;i<pp.size();i++){
//       rs5=st7.executeQuery("SELECT * FROM cloudlet where cloudletID!='"+pp.get(i)+"'");
//       while(rs5.next()){
//           String a=rs5.getString(1);
//           System.out.println(a);
//           
//       }
//               }
     
       
       System.out.println("cloudlet\tsize\t\tVM\tBW\tStart Time\tEnd Time\n***************************************************************************************************************************\n");
        for(int j=0;j<cldfs.size();j++){
         for(int i=0;i<vmbw.size();i++){
            Random r=new Random();
      int rr=r.nextInt(55);
      Random r1=new Random();
      int rr1=r1.nextInt(60);
                 if(vmbw.get(i)>cldfs.get(j)){
                     if(rr<rr1){
                         vmid1.remove(i);
                     vmbw.remove(vmid.get(i));
                       System.out.println("cloudlet"+cid.get(j) +"\t["+cldfs.get(j) +"]\t==>\tvm:"+vmid.get(i) +"\t["+vmbw.get(i)+"]\t0:"+(rr1+i)+"\t0:"+(rr1+5+j)+"\n");
                     long temp= (vmbw.get(i)-cldfs.get(j));
                     vmbw.set(i, temp);
                     break;
                 }
             }
    }
        }
        int idl=vmid.size()-vmid1.size();
        System.out.println("IDLE VMs   "+idl);
        System.out.println("Active VMs    "+(vmid.size()-idl));
        
        }catch(Exception e){e.printStackTrace();}
    }
    
      public static void main(String args[]){
          file5 f5=new file5();
          f5.cloudlet();
          f5.opt();
      }
    
}
