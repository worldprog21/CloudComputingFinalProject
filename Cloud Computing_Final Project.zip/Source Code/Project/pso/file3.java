/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.Vm;

/**
 *
 * @author CabinK1
 */
public class file3 {
     public static String str;
    public int nofVm,nofCloudlets;
    public static List<Vm> vmlist;
    public static List<org.cloudbus.cloudsim.Cloudlet> cloudletList;
    public static DatacenterBroker[] broker=file2.bId;
    public static ArrayList vDetails=new ArrayList();
    public int pesNumber=1;
    
    void Vm()
    {
        Connection con=null;
        Statement st=null;
        ResultSet rs=null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=(Connection)(java.sql.Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/ACO","root","");
           st = con.createStatement();
           st.executeUpdate("TRUNCATE TABLE vm");
       BufferedWriter bw1=new BufferedWriter(new FileWriter("vm.txt"));
        System.out.println("Enter Number of Virtual Machine to be Create :");
        
        int vm;
//        
        Scanner sc=new Scanner(System.in); 

        vm=Integer.valueOf(sc.nextInt());

        
        nofVm=vm;
    
        Random r=new Random();
        Random r1=new Random();
        Random r2=new Random();
        vmlist = new ArrayList<Vm>();
        ArrayList<Vm> vbList=new ArrayList<Vm>();
        int vmid,mips,ram,brokerId;
        long size,bw;
        long[] sizes={10000,15000,20000,250000};
        int[] rams={512,1024,2048,3072};
        int[] bws={10000,20000,15000,30000,50000};
        String vmm;
        Vm vm1;
        DatacenterBroker sBroker;
        int b;//=r.nextInt(broker.length);
        for(int i=0;i<nofVm;i++)
        {
            b=r.nextInt(broker.length);
            vmid = i;
            mips = r.nextInt(1000);
            size = sizes[r1.nextInt(4)]; //image size (MB)
            ram = rams[r2.nextInt(4)]; //vm memory (MB)
            bw = bws[r.nextInt(5)];
            pesNumber = 1; //number of cpus
            vmm = "Xen"; //VMM name          
            brokerId=broker[b].getId();
            vm1 = new Vm(vmid, brokerId, mips, pesNumber, ram, bw, size, vmm, new CloudletSchedulerTimeShared());
            vmlist.add(vm1);
            vDetails.add(vmid+"\t"+brokerId+"\t"+mips+"\t"+ram+"\t"+bw+"\n\n");
            st.executeUpdate("INSERT INTO vm VALUES('"+vmid+"','"+brokerId+"','"+mips+"','"+ram+"','"+bw+"')");
            sBroker=broker[b];
            vbList.add(vm1);
            sBroker.submitVmList(vbList);
            vbList.clear();
        }
        
       // JOptionPane.showMessageDialog(null,nofVm+" Virtual Machines created successfully");
        System.out.print("VM Id"+"\t"+"Broker Id"+"\t"+"Mips"+" \t"+"RAM"+"\t"+"BW\n\n");
        bw1.write("VM Id"+"\t"+"Broker Id"+"\t"+"Mips"+" \t"+"RAM"+"\t"+"BW");
        bw1.newLine();
        System.out.print("================================================================\n\n");
        for(int i=0;i<vDetails.size();i++) {
            System.out.println(vDetails.get(i).toString()+"\n");
            bw1.write(vDetails.get(i).toString());
            bw1.newLine();
        }
        bw1.close();
        //JOptionPane.showMessageDialog(null," Virtual Machines submitted to respective Brokers successfully");
        }catch(Exception e){e.printStackTrace();}
    }
    
//    void Vmclass(String ss)
//    {
//        file3 f3=new file3();
//        f3.Vm(ss);
//    }
    
    
}
