/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

/**
 *
 * @author EGCMatlab
 */
public class aaa {
    public static void main(String args[]){
        try{
            String str[] ={"10","13"};
           PowerAware1 p1=new PowerAware1();
           p1.main(str);
        }catch(Exception ex){
            
        }
    }
}
