/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Random;

/**
 *
 * @author NANA
 */
public class pso2 {
    
    public static void main(String args[]){
         Connection con=null;
        Statement st=null,st1=null,st2=null;
        ResultSet rs=null,rs1=null,rs2=null;
        try{
       
             Class.forName("com.mysql.jdbc.Driver");
            con=(Connection)(java.sql.Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/ACO","root","");
           st = con.createStatement();
           st1= con.createStatement();
            st2= con.createStatement();
            
            rs=st.executeQuery("SELECT * FROM alloc");
            int tot=0,tt=0;int dl=0;int p=0;int cost1=0;
            System.out.println("Cloudlet\tSize\tVM\tBW\tTask Completion Time\tstart_time\tend_time\tDead Line\tCost\tStatus\n*********************************************************************************************************************************\n");
            while(rs.next()){
                String a=rs.getString(1);
                String b=rs.getString(2);
                String c=rs.getString(3);
                String d=rs.getString(4);
                p++;
            int e=Integer.valueOf(rs.getString(5));
              int f=Integer.valueOf(rs.getString(6));
              Random rr=new Random();
              int rr1=rr.nextInt(20);
              if(rr1==0||rr1==1||rr1==2||rr1==3||rr1==4){
                  rr1=5;
              }
              int rr2=(rr1-Math.abs(e-f));
              int cost=(Math.abs(e-f))*10;
              cost1=cost1+cost;
              String stus="";
              if(rr2<0){
                  stus="Dead Line Met";
                  dl++;
              }
               if(rr2>=0){
                  stus="No Dead Line Met";
              }
                System.out.println(a+"\t"+b+"\t"+c+"\t"+d+"\t\t"+rr1+"\t\t"+e+"\t\t   "+f+"\t           "+rr2+"\t\t"+cost+"\t"+stus);
                tot=tot+Math.abs(e-f);
                
                tt++;
                
            }
            
            rs1=st1.executeQuery("SELECT vmid FROM vm");
            int xx=0;
            while(rs1.next()){
               xx++;
                        
            }
            System.out.println(xx);
            
          rs2=st2.executeQuery("SELECT distinct(vm) FROM alloc");
          int ac=0;
          while(rs2.next()){
              ac++;
          }
            System.out.println("Active VM "+ac);
            System.out.println("Idle VM "+(xx-ac));
          System.out.println("Total Number of Process: "+p);
            System.out.println("Number of Dead Line Met: "+dl);
            
               BufferedWriter bw3=new BufferedWriter(new FileWriter("./h5.txt"));
          
            bw3.write(String.valueOf(xx-ac));
            bw3.close();
            
            BufferedWriter bw=new BufferedWriter(new FileWriter("./h1.txt"));
          
            bw.write(String.valueOf(dl));
            bw.close();
            
             BufferedWriter bw1=new BufferedWriter(new FileWriter("./h3.txt"));
          
            bw1.write(String.valueOf(cost1));
            bw1.close();
        }catch(Exception e){}
        
        
    }
    
    
    
}
