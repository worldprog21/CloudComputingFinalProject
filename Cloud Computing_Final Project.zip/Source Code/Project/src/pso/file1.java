/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.VmSchedulerSpaceShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import pso.pso;


/**
 *
 * @author CabinK1
 */
public class file1 {

    public static org.cloudbus.cloudsim.Datacenter dataCenter[];
    public static int nofDatacenter, nofBrokers;
    String str;
    public static String dcName, bName;
    public static ArrayList details = new ArrayList();
    public static DatacenterBroker[] bId;
    public int dc;

    private static org.cloudbus.cloudsim.Datacenter createDatacenter(String name) {
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;

        List<Host> hostList = new ArrayList<Host>();
        List<Pe> peList = new ArrayList<Pe>();
        //NO. of pes
        Random r = new Random();
        int nMip, nPe;
        int mips;
        do {
            nPe = r.nextInt(5);
        } while (nPe < 1);
        for (int i = 0; i < nPe; i++) {
            do {
                nMip = r.nextInt(2000);
            } while (nMip < 300);
            mips = nMip;
            peList.add(new Pe(i, new PeProvisionerSimple(mips)));
        }
        //No. of machines
        int nMachines;
        do {
            nMachines = r.nextInt(5);
        } while (nMachines < 2);
        int[] rams = {1024, 2048, 3072};
        int[] bws = {10000, 15000, 20000, 25000};
        int nRam, hostId, ram, bw, nBw;
        long storage;
        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) (java.sql.Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/ACO", "root", "");
            st = con.createStatement();
//            st.executeUpdate("TRUNCATE TABLE dc");
            for (int i = 0; i < nMachines; i++) {
                nRam = r.nextInt(2);
                   
                nBw = r.nextInt(4);
                hostId = i;
                ram = rams[nRam]; //host memory (MB)
                storage = 1000000; //host storage
                bw = bws[nBw];
                st.executeUpdate("INSERT INTO dc VALUES('" + dcName + "','" + nMachines + "','" + hostId + "','" + nPe + "','" + ram + "','" + bw + "')");

                details.add(dcName + "\t\t" + nMachines + "\t" + hostId + "\t" + nPe + "\t" + ram + "\t" + bw + "\n");
                System.out.println(i + " vali    \\" + dcName + "\t" + nMachines + "\t\t" + hostId + "\t\t" + nPe + "\t\t" + ram + "\t" + bw + "\n");
                Host h = new Host(hostId,
                        new RamProvisionerSimple(ram),
                        new BwProvisionerSimple(bw),
                        storage,
                        peList,
                        new VmSchedulerSpaceShared(peList));
                hostList.add(h);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        String arch = "x86";      // system architecture
        String os = "Linux";          // operating system
        String vmm = "Xen";
        double time_zone = 10.0;         // time zone this resource located
        double cost = 3.0;              // the cost of using processing in this resource
        double costPerMem = 0.05;		// the cost of using memory in this resource
        double costPerStorage = 0.001;	// the cost of using storage in this resource
        double costPerBw = 0.0;			// the cost of using bw in this resource
        LinkedList<Storage> storageList = new LinkedList<Storage>();	//we are not adding SAN devices by now

        DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch, os, vmm, hostList, time_zone, cost, costPerMem, costPerStorage, costPerBw);
        org.cloudbus.cloudsim.Datacenter datacenter = null;
        try {
            datacenter = new org.cloudbus.cloudsim.Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
        } catch (Exception e) {
            //e.printStackTrace();
        }

        return datacenter;


    }

    private static DatacenterBroker createBroker() {

        DatacenterBroker broker = null;
        try {
            broker = new DatacenterBroker(bName);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return broker;
    }

    void load() {
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("datacenter.txt"));
            System.out.println("Enter the Number of Datacenters:\n");
            //Scanner sc=new Scanner(System.in);
            Scanner sc=new Scanner(System.in);
            
            int aa = sc.nextInt();
            //str=jTextField1.getText();

            nofDatacenter = aa;

            dataCenter = new org.cloudbus.cloudsim.Datacenter[nofDatacenter];

            System.out.println("dcname" + "\t" + "No of machines" + "\t" + "host id" + " \t" + "no. pes" + "\t" + "ram\t" + "\t" + "bw\n\n");

            bw.newLine();
            for (int i = 0; i < nofDatacenter; i++) {

                dcName = "Datacenter_" + i;
                dataCenter[i] = createDatacenter("Datacenter_" + i);

            }
            //  JOptionPane.showMessageDialog(null,nofDatacenter+" Data centers created");
            bw.write("DataCenterName" + "      " + "No of machines" + "\t" + "Host id" + " \t" + "No. PEs" + "\t" + "RAM" + "\t" + "BW");
            bw.newLine();
            System.out.print("DataCenterName" + "      " + "No of machines" + "\t" + "Host id" + " \t" + "No. PEs" + "\t" + "RAM" + "\t" + "BW\n\n");
            System.out.print("=======================================================================================\n\n");
            for (int i = 0; i < details.size(); i++) {
                System.out.print(details.get(i).toString() + "\n");
                bw.write(details.get(i).toString());
                bw.newLine();
            }
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) {
        file1 f1 = new file1();
       
        f1.load();
        System.out.println();
        System.out.println("# # # # # # # # # # # # # # # # # # # # # # # # # # #\n Broker Creation\n # # # # # # # # # # # # # # # # # # # # # # # # # # #");
        
     CloudSim.init(1, Calendar.getInstance(), false);
        System.out.println("started");
      file2 f2=new file2();
      f2.broker();
        
        System.out.println();
        System.out.println("# # # # # # # # # # # # # # # # # # # # # # # # # # #\n VM  Creation\n # # # # # # # # # # # # # # # # # # # # # # # # # # # # #");
        
        file3 f3=new file3();
        f3.Vm();
        
        System.out.println();
        System.out.println("# # # # # # # # # # # # # # # # # # # # # # # # # # #\n Cloudlet Creation\n # # # # # # # # # # # # # # # # # # # # # # # # # # #");
        
        file4 f4=new file4();
        f4.cloudletclass();
//        file5 f5=new file5();
//        f5.euclidean();
        
//       pso f6=new pso();
//       pso2 p2=new pso2();
//        System.out.println("Enter 1 to perform Particle Swarm Optimization");
//       
//        Scanner sc=new Scanner(System.in);
//       int a1=sc.nextInt();
//       if(a1==1){
//        f6.main(null);
//        p2.main(null);
//       }
//       else{
//           System.out.println("Process Stopped");
//           System.exit(0);
//       }
    }
}
