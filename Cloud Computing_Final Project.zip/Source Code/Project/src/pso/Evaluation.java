/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 *
 * @author ETPL10
 */
public class Evaluation {
    public static double d1;
    public static double d2;
    public static void main(String args[]){
        
        try{
            BufferedReader br=new BufferedReader(new FileReader("./h1.txt"));
            String line1=br.readLine();
            
            BufferedReader br1=new BufferedReader(new FileReader("./h2.txt"));
            String line2=br1.readLine();
           d1=Double.valueOf(line1);
            d2=Double.valueOf(line2);
            BarChartDemo_1 b=new BarChartDemo_1("");
            b.setVisible(true);
              BarChartDemo_11 b1=new BarChartDemo_11("");
            b1.setVisible(true);
        }catch(Exception e){}
        
        
    }
}
