/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pso;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;
import static pso.pso3.vmid;
import static pso.pso3.vmid1;

/**
 *
 * @author ETPL10
 */
public class pso {
     public static ArrayList<String>cid=new ArrayList<String>();
     public static ArrayList<String>vid=new ArrayList<String>();
      public static ArrayList<Long>cs=new ArrayList<Long>();
      public static ArrayList<Long>vs=new ArrayList<Long>();
       public static ArrayList<String>vmid1=new ArrayList<String>();
       public static int jj;
        int jj1=0;
     public  void vm(){
         System.out.println("************************************************\n");
//        int idl=vmid.size()-vmid1.size();
//        System.out.println("IDLE VMs   "+idl);
//        System.out.println("Active VMs    "+(vmid.size()-idl));
       }
    public void pso1(){
        System.out.println("****************************Particle Swarm Optimization***********************\n");
        Connection con=null;
        Statement st=null,st1=null,st2=null;
        ResultSet rs=null,rs1=null;
        try{
             Class.forName("com.mysql.jdbc.Driver");
            con=(Connection)(java.sql.Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/ACO","root","");
           st = con.createStatement();
           st1= con.createStatement();
            st2= con.createStatement();
            st2.executeUpdate("TRUNCATE TABLE alloc");
           rs=st.executeQuery("SELECT * FROM cloudlet  order by filesize ASC");
           int x=0;
           while(rs.next()){
               String a=rs.getString(1);
               String b=rs.getString(5);
               cid.add(a);
               cs.add(Long.valueOf(b));
               x++;
           }
           System.out.println(x);
           System.out.println("Number of Generations(Cloudlets) :"+x);
            rs1=st1.executeQuery("SELECT * FROM vm");
            int y=0;
            while(rs1.next()){
                String a=rs1.getString(1);
                String b=rs1.getString(5);
                vid.add(a);
                vmid1.add(a);
                vs.add(Long.valueOf(b));
                y++;
            }
            
            System.out.println("Resource Allocated..");   
            System.out.println("Number of Virtual Machine Reserves :"+y+"\n");
            
            System.out.println("Individual Population of Cloudlets");
            
            for(int i=0;i<cid.size();i++){
                System.out.println("cloudlet:"+cid.get(i) +"\t\t"+cs.get(i));
            }
            
            System.out.println("********************Best Solution*********************\n");
            String ss="",ss1="";
             jj=0;
           
           for(int j=0;j<cs.size();){
            Random r=new Random();
             int r1=r.nextInt(cs.size());
            int kk=0;
             if(!ss.contains(String.valueOf(r1))){
                  ss=ss+String.valueOf(r1);
                  j++;
//             System.out.println("r1"+r1);
               
         for(int i=0;i<vs.size();i++){
            kk++;
            Random rr1=new Random();
      int rr=rr1.nextInt(55);
      Random r11=new Random();
      int r1r=r11.nextInt(60);
                 if(vs.get(i)>cs.get(r1)){
                     jj++;
                   
                     long temp= (vs.get(i)-cs.get(r1));
                     vs.set(i, temp);
//                     System.out.println("cloudlet"+cid.get(r1) +"\t["+cs.get(r1) +"]\t==>\tvm:"+vid.get(i) +"\t["+vs.get(i)+"]");
                    st.executeUpdate("INSERT INTO alloc VALUES('cloudlet"+cid.get(r1)+"','"+cs.get(r1)+"','vm"+vid.get(i)+"','"+vs.get(i)+"','"+(r1r+i)+"','"+(r1r+8+j)+"')");
                     break;
                 }
         }
             }
           jj1=kk;
             }

     
           
              
    }catch(Exception e){e.printStackTrace();}
         
}
    
    public static void main(String args[]){
        pso p=new pso();
      
        p.pso1();
          p.vm();
          pso2 p2=new pso2();
          p2.main(null);
     
    }
  
}
